# Automated Testing

## Unit test

### Start
Docker Compose: `docker-compose up`

## Standard of Script
1. All `TestCase` should be extends `\Swoft\Test\AbstractTestCase` class