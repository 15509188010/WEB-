# 资源目录

- views - 视图资源
- languages - 翻译资源
